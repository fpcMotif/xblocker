// Function to block the first 20 comment tweets on a tweet page
async function blockFirst20CommentTweets() {
	// Check if we're on a tweet page
	const urlPattern = /https?:\/\/(www\.)?x\.com\/[^\/]+\/status\/\d+/;
	if (!urlPattern.test(window.location.href)) {
		console.log("Not on a tweet page. Exiting.");
		return;
	}

	// Get all tweet articles on the page
	const tweetArticles = document.querySelectorAll(
		'article[data-testid="tweet"]',
	);

	// Skip the main tweet (the first one)
	const commentTweets = Array.from(tweetArticles).slice(1);

	// Limit to first 20 comments
	const first20Comments = commentTweets.slice(0, 50);

	for (const tweetArticle of first20Comments) {
		await blockTweet(tweetArticle);
	}

	console.log("Finished blocking the first 50 comment tweets.");
}

// Function to get the whitelist from chrome.storage.local
function getWhitelist(callback) {
	chrome.storage.local.get('whitelist', (result) => {
		const whitelist = result.whitelist || [];
		callback(whitelist);
	});
}

// Function to save the whitelist to chrome.storage.local
function saveWhitelist(whitelist) {
	chrome.storage.local.set({ whitelist: whitelist }, () => {
		console.log('Whitelist saved');
	});
}

// Function to add a username to the whitelist
function addToWhitelist(username) {
	getWhitelist((whitelist) => {
		if (!whitelist.includes(username)) {
			whitelist.push(username);
			saveWhitelist(whitelist);
			alert(`Added @${username} to whitelist.`);
		} else {
			alert(`@${username} is already in the whitelist.`);
		}
	});
}

// Function to add the block and whitelist buttons to the page
function addButtons() {
	const buttonContainer = document.createElement("div");
	buttonContainer.style.position = "fixed";
	buttonContainer.style.bottom = "20px";
	buttonContainer.style.right = "20px";
	buttonContainer.style.zIndex = "9999";

	// Block Button
	const blockButton = document.createElement("button");
	blockButton.textContent = "Block First 20 Comments";
	blockButton.style.padding = "10px";
	blockButton.style.backgroundColor = "#1DA1F2";
	blockButton.style.color = "white";
	blockButton.style.border = "none";
	blockButton.style.borderRadius = "5px";
	blockButton.style.cursor = "pointer";
	blockButton.style.marginBottom = "10px";

	blockButton.addEventListener("click", blockFirst20CommentTweets);

	// Whitelist Button
	const whitelistButton = document.createElement("button");
	whitelistButton.textContent = "Add to Whitelist";
	whitelistButton.style.padding = "10px";
	whitelistButton.style.backgroundColor = "#1DA1F2";
	whitelistButton.style.color = "white";
	whitelistButton.style.border = "none";
	whitelistButton.style.borderRadius = "5px";
	whitelistButton.style.cursor = "pointer";

	whitelistButton.addEventListener("click", () => {
		const username = prompt("Enter the username to whitelist (without @):");
		if (username) {
			addToWhitelist(username);
		}
	});

	buttonContainer.appendChild(blockButton);
	buttonContainer.appendChild(whitelistButton);
	document.body.appendChild(buttonContainer);
}

// Modify the blockTweet function to skip whitelisted users
async function blockTweet(tweetArticle) {
	// Get the tweet author's username
	const userLink = tweetArticle.querySelector('a[href^="/"][role="link"]');
	let username = null;
	if (userLink) {
		const urlParts = userLink.getAttribute('href').split('/');
		username = urlParts[1];
	}

	return new Promise((resolve) => {
		getWhitelist(async (whitelist) => {
			if (username && whitelist.includes(username)) {
				console.log(`Skipping @${username}, as they are in the whitelist.`);
				resolve();
				return;
			}

			// Find the three dots button
			const moreButton = tweetArticle.querySelector('[aria-label="More"]');

			if (moreButton) {
				// Simulate click on the three dots menu
				moreButton.click();

				// Wait for the menu to appear
				await new Promise((r) => setTimeout(r, 500));

				// Find the "Block @username" menu item
				const menuItems = document.querySelectorAll('[role="menuitem"]');
				let blockItem = null;
				let hideItem = null;
				menuItems.forEach((item) => {
					const itemText = item.innerText.trim();
					if (itemText.startsWith("Block @")) {
						blockItem = item;
					} else if (itemText.startsWith("Hide")) {
						hideItem = item;
					}
				});

				if (blockItem) {
					// Simulate click on "Block @username"
					blockItem.click();

					// Wait for the confirmation modal to appear
					await new Promise((r) => setTimeout(r, 500));

					// Find and click the "Block" button in the modal
					const confirmButton = document.querySelector(
						'[data-testid="confirmationSheetConfirm"]',
					);
					if (confirmButton) {
						confirmButton.click();
					}
				} else if (hideItem) {
					console.log("Block option not found, attempting to hide the tweet.");
					// Simulate click on "Hide"
					hideItem.click();

					// Wait for the confirmation modal to appear
					await new Promise((r) => setTimeout(r, 500));

					// Find and click the "Hide" button in the modal
					const confirmButton = document.querySelector(
						'[data-testid="confirmationSheetConfirm"]',
					);
					if (confirmButton) {
						confirmButton.click();
					}
				} else {
					console.log("Neither Block nor Hide option found.");
				}

				// Wait a bit before proceeding to the next tweet
				await new Promise((r) => setTimeout(r, 500));
			} else {
				console.log("More button not found for a comment tweet.");
			}
			resolve();
		});
	});
}

// Function to mute the first 50 comment tweets on a tweet page
async function muteFirst50CommentTweets() {
	// Check if we're on a tweet page
	const urlPattern = /https?:\/\/(www\.)?x\.com\/[^\/]+\/status\/\d+/;
	if (!urlPattern.test(window.location.href)) {
		console.log("Not on a tweet page. Exiting.");
		return;
	}

	// Get all tweet articles on the page
	const tweetArticles = document.querySelectorAll('article[data-testid="tweet"]');

	// Skip the main tweet (the first one)
	const commentTweets = Array.from(tweetArticles).slice(1);

	// Limit to first 50 comments
	const first50Comments = commentTweets.slice(0, 50);

	for (const tweetArticle of first50Comments) {
		await muteTweet(tweetArticle);
	}

	console.log("Finished muting the first 50 comment tweets.");
}

// Function to mute a tweet
async function muteTweet(tweetArticle) {
	// Get the tweet author's username
	const userLink = tweetArticle.querySelector('a[href^="/"][role="link"]');
	let username = null;
	if (userLink) {
		const urlParts = userLink.getAttribute('href').split('/');
		username = urlParts[1];
	}

	return new Promise((resolve) => {
		getWhitelist(async (whitelist) => {
			if (username && whitelist.includes(username)) {
				console.log(`Skipping @${username}, as they are in the whitelist.`);
				resolve();
				return;
			}

			// Find the "More" button
			const moreButton = tweetArticle.querySelector('[aria-label="More"]');

			if (moreButton) {
				// Simulate click on the "More" menu
				moreButton.click();

				// Wait for the menu to appear
				await new Promise((r) => setTimeout(r, 500));

				// Find the "Mute @username" menu item
				const menuItems = document.querySelectorAll('[role="menuitem"]');
				let muteItem = null;
				menuItems.forEach((item) => {
					const itemText = item.innerText.trim();
					if (itemText.startsWith("Mute @")) {
						muteItem = item;
					}
				});

				if (muteItem) {
					// Simulate click on "Mute @username"
					muteItem.click();

					// Wait for the confirmation modal to appear
					await new Promise((r) => setTimeout(r, 500));

					// Find and click the "Mute" button in the modal
					const confirmButton = document.querySelector('[data-testid="confirmationSheetConfirm"]');
					if (confirmButton) {
						confirmButton.click();
					}
				} else {
					console.log("Mute option not found.");
				}

				// Wait before proceeding to the next tweet
				await new Promise((r) => setTimeout(r, 500));
			} else {
				console.log("More button not found for a comment tweet.");
			}
			resolve();
		});
	});
}

// Function to add the block, mute, and whitelist buttons to the page
function addButtons() {
	const buttonContainer = document.createElement("div");
	buttonContainer.style.position = "fixed";
	buttonContainer.style.bottom = "20px";
	buttonContainer.style.right = "20px";
	buttonContainer.style.zIndex = "9999";

	// Block Button
	const blockButton = document.createElement("button");
	blockButton.textContent = "Block First 20 Comments";
	blockButton.style.padding = "10px";
	blockButton.style.backgroundColor = "#1DA1F2";
	blockButton.style.color = "white";
	blockButton.style.border = "none";
	blockButton.style.borderRadius = "5px";
	blockButton.style.cursor = "pointer";
	blockButton.style.marginBottom = "10px";

	blockButton.addEventListener("click", blockFirst20CommentTweets);

	// Mute Button
	const muteButton = document.createElement("button");
	muteButton.textContent = "Mute First 50 Comments";
	muteButton.style.padding = "10px";
	muteButton.style.backgroundColor = "#1DA1F2";
	muteButton.style.color = "white";
	muteButton.style.border = "none";
	muteButton.style.borderRadius = "5px";
	muteButton.style.cursor = "pointer";
	muteButton.style.marginBottom = "10px";

	muteButton.addEventListener("click", muteFirst50CommentTweets);

	// Whitelist Button
	const whitelistButton = document.createElement("button");
	whitelistButton.textContent = "Add to Whitelist";
	whitelistButton.style.padding = "10px";
	whitelistButton.style.backgroundColor = "#1DA1F2";
	whitelistButton.style.color = "white";
	whitelistButton.style.border = "none";
	whitelistButton.style.borderRadius = "5px";
	whitelistButton.style.cursor = "pointer";

	whitelistButton.addEventListener("click", () => {
		const username = prompt("Enter the username to whitelist (without @):");
		if (username) {
			addToWhitelist(username);
		}
	});

	buttonContainer.appendChild(blockButton);
	buttonContainer.appendChild(muteButton);
	buttonContainer.appendChild(whitelistButton);
	document.body.appendChild(buttonContainer);
}

// Update checkPageAndAddButton function
function checkPageAndAddButton() {
	const url = window.location.href;
	const tweetPagePattern = /https?:\/\/(www\.)?x\.com\/[^\/]+\/status\/\d+/;
	const timelinePattern = /https?:\/\/(www\.)?x\.com\/i\/timeline/;

	if (timelinePattern.test(url)) {
		// Do not add buttons or run code on the timeline page
		console.log("On timeline page. Exiting.");
		return;
	}

	// Add buttons on tweet pages and user feed pages
	if (
		tweetPagePattern.test(url) ||
		/^https?:\/\/(www\.)?x\.com\/[^\/]+\/?$/.test(url)
	) {
		addButtons();
	}
}

// Run the main functions
checkPageAndAddButton();

// Listen for URL changes (for single-page applications)
let lastUrl = location.href;
new MutationObserver(() => {
	const url = location.href;
	if (url !== lastUrl) {
		lastUrl = url;
		checkPageAndAddButton();
	}
}).observe(document, { subtree: true, childList: true });
